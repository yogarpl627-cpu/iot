// Library untuk menggunakan LCD I2C 
#include <LiquidCrystal_I2C.h>

// Mengatur alamat LCD ke 0x27 untuk layar 16 kolom dan 2 baris
LiquidCrystal_I2C lcd(0x27,16,2);

// Pengaturan pin yang digunakan
int sensorPir = 4;
int statusPir = 0; // 0 == LOW, 1 == HIGH
int ledRed = 11;
int ledBlue = 9;
int ledYellow = 8;
int buzzerPin = 7;

// Kode ini hanya dijalankan sekali saat perangkat dinyalakan
void setup() {
  /*
  Serial.begin().
  Inisialisasi komunikasi serial untuk pesan di monitor.

  Kecepatan transmisi data: 9600bps (bit per second)
  */
  Serial.begin(9600);
  Serial.println("Sistem Deteksi Gerak");
  Serial.println("m faisal yoa ardana ");

  lcd.init();                     // Aktifkan LCD
  lcd.backlight();                // Hidupkan lampu latar LCD
  lcd.setCursor(0,0);             // Pindahkan kursor ke kolom 0 baris 0
  lcd.print("     Sistem     ");  // Tampilkan teks di LCD
  lcd.setCursor(0,1);             // Pindahkan kursor ke kolom 0 baris 1
  lcd.print("  Deteksi Gerak ");

  // Tahan eksekusi sebentar agar layar muncul
  delay(1000); // 1 detik == 1000 ms (millisecond)

  /*
  pinMode() untuk menetapkan
  pin yang digunakan sebagai input atau output. */
  pinMode(sensorPir, INPUT);
  pinMode(ledRed, OUTPUT);
  pinMode(ledBlue, OUTPUT);
  pinMode(ledYellow, OUTPUT);
  pinMode(buzzerPin, OUTPUT);
}

// Kode ini akan terus dieksekusi berulang kali
void loop() {
  // digitalRead() untuk membaca input Digital.
  statusPir = digitalRead(sensorPir); 
  if(statusPir == HIGH){
    /*
    digitalWrite() untuk menetapkan
    nilai HIGH atau LOW pada Output Digital.

    Di sini, HIGH untuk menyalakan dan LOW untuk mematikan lampu LED.*/
    digitalWrite(ledYellow, LOW);

    // Hidupkan buzzer dengan frekuensi 500 Hz
    tone(buzzerPin, 500);
    
    // Hapus teks di LCD
    lcd.clear();
    lcd.setCursor(0,0);
    lcd.print("  khoirul ");
    lcd.setCursor(0,1);
    lcd.print("  Ada Gerakan");

    Serial.println("Ada Gerakan");

    /*
    Kode di bawah membuat lampu merah dan biru bergantian menyala
    sebanyak 10 kali menggunakan perulangan for.
    */
    for(int i = 1; i <= 10;i++){
      if(i % 2 != 0){
        // Menyalakan lampu merah jika 'i' ganjil
        digitalWrite(ledRed, HIGH);
      }else{
        // Menyalakan lampu biru jika 'i' genap
        digitalWrite(ledBlue, HIGH);
      }
      // Menyalakan lampu sebentar sebelum dimatikan
      delay(250);
      // Mematikan lampu LED
      digitalWrite(ledRed, LOW);
      digitalWrite(ledBlue, LOW); 
    }
    // Mematikan buzzer
    noTone(buzzerPin);
  }else{
    digitalWrite(ledRed, LOW);
    digitalWrite(ledBlue, LOW);
    digitalWrite(ledYellow, HIGH);
    lcd.clear();
    lcd.setCursor(0,0);
    lcd.print("  yoga ");
    lcd.setCursor(0,1);
    lcd.print(" bergerak");
    Serial.println("Ada gerakan");
  }
  // Jeda waktu antara eksekusi kode atau deteksi sensor
  delay(1000); // 1 detik == 1000 ms (millisecond)
}
